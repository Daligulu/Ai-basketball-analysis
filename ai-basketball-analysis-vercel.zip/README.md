# AI Basketball Analysis (Vercel-ready)

一个完整可部署在 **Vercel** 的 Next.js 14 网站：上传或实时采集篮球视频，基于浏览器端 **TensorFlow.js** 姿态识别与简单的颜色聚类进行投篮分析（出手/命中/角度等启发式指标）。

> 设计灵感来自开源项目 [chonyy/AI-basketball-analysis](https://github.com/chonyy/AI-basketball-analysis)，本实现选择**前端推理**以适配 Vercel 的无服务器运行环境（无需 GPU / 后端服务）。

## 主要功能
- MoveNet/BlazePose（通过统一 `pose-detection` API）的人体关键点检测，支持**视频文件**与**摄像头**。
- 通过膝盖角度、肘部伸展与手腕位置变化近似判断**出手**时刻；
- 通过橙色像素聚类跟踪球并判断是否穿过用户绘制的**篮筐 ROI**，得到**命中/未进**；
- 统计总出手数、命中数，导出 JSON。

## 本地开发
```bash
pnpm i   # 或 npm i / yarn
pnpm dev # http://localhost:3000
```

## 一键部署到 Vercel
1. 将本项目推到你的 Git 仓库（GitHub/GitLab/Bitbucket）。
2. 打开 https://vercel.com 新建 Project，导入该仓库，**Framework 选择 Next.js**；其余保持默认即可。
3. 首次构建完成后即可访问预览域名；合并到主分支自动生产部署。

> 参考：Next.js 在 Vercel 上的官方部署文档。

## 使用提示
- 请在分析页**拖拽绘制篮筐区域**（白框），以便命中判定；
- 使用固定机位、篮筐清晰可见、篮球颜色接近橙色的视频效果更好；
- 本 Demo 的检测/判定为启发式近似，若需专业/稳定的效果，建议结合更强的模型与标注数据微调。

## 许可
MIT
